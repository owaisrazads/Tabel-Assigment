import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "../screens/home/Home";
import About from "../screens/about/About";
import Contact from "../screens/contact/Contact";
import Navbar from "../components/Navbar";


const Router = () => {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="*" element={<Navbar />} />

        </Routes>
      </BrowserRouter>
    </>
  );
};

export default Router;
