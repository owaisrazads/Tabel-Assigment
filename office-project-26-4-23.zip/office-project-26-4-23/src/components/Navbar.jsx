import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <>
      <>
        <nav className="flex items-center sticky top-0 z-20 bg-blue-400  px-5 justify-evenly max-[1900px]:t">
          <div className="navbar">
            <p className="font-bold text-xl text-white">
              <Link to="/">AH-MOBILE</Link>{" "}
            </p>
          </div>
          <div>
            <ul className="flex gap-5 text-white font-medium">
              <li>
                <Link to="/">Home</Link>
              </li>
              <li>
                <Link to="/about">About</Link>
              </li>
              <li>
                <Link to="/contact">Contact</Link>
              </li>
            </ul>
          </div>
        </nav>
      </>
    </>
  );
};

export default Navbar;
