import right from "../../assets/1.png";
import left from "../../assets/2.png";
import map from "../../assets/Rectangle 19.png";
import Navbar from "../../components/Navbar";

const Contact = () => {
  return (
    <div>
      <Navbar />
      <div  className="justify-end flex mt-5">
        <img className="max-[1050px]:h-[80px]" src={right} alt="" />
       
      </div>
      <div className="flex justify-center">
        
      <div className="box rounded-xl bg-white drop-shadow-xl mx-5  mt-20 mb-5  max-[890px]:mx-[50vw] max-[700px]:h-auto p-5 max-[750px]:justify-center">
      <p className="text-center text-blue-400 font-medium text-2xl mt-5 underline underline-offset-8">
            Get In Touch
          </p>
       <div className="parent flex flex-wrap justify-evenly">
       <div className="form--div ">
          <form className="mt-10">
            <input
              className="w-[422px] h-[61px] rounded-lg max-[890px]:w-[380px] max-[890px]:h-[41px]"
              placeholder="   First_Name Last_Name"
            />
            <br />
            <br />
            <input
              className="w-[422px] h-[61px] rounded-lg max-[890px]:w-[380px] max-[890px]:h-[41px]"
              placeholder="   Email Address"
            />
            <br />
            <br />
            <textarea
              className="w-[422px] h-[137px] max-h-36 min-h-14 rounded-lg max-[890px]:w-[380px] max-[890px]:h-[80px] "
              placeholder="   Your Message"
            />
            <br />
            <br /><br />
            <button className="w-[422px] h-[50px] bg-blue-600 rounded-lg text-white max-[910px]:w-[380px] h-[40px]:rounded-sm">
              Send a Message
            </button>
          </form>
        </div>
        
        <div className="detalis mt-10 ml-5 ">
          <div className="para text-lg font-normal max-[890px]:text-sm max-[890px]:font-light  ">
            <p className="">
            <i class="fa-solid fa-location-dot"></i> Infomation technologies building, <br />   Victoria Island, Lagos,
              Nigeria.
            </p>
            <p className="mt-7 max-[890px]:mt-4 max-[745px]:hidden"> <i class="fa-solid fa-phone"></i> +234 081-1236-4568</p>
            <p className="mt-7 max-[890px]:mt-4 max-[745px]:hidden"> <i class="fa-solid fa-envelope"></i> hello@info.com.ng</p>
            <div className="flex mt-4 r">
            <p><i class="fa-brands fa-linkedin "></i></p>
            <p className="ml-5"><i class="fa-brands fa-youtube"></i></p>
            <p className="ml-5"><i class="fa-brands fa-instagram"></i></p>
            <p className="ml-5"><i class="fa-brands fa-whatsapp"></i></p>
            </div>
            <img className=" mt-7 max-[890px]:w-[290px] max-[890px]:h-[100px] max-[770px]:hidden" src={map} alt="map" />
          </div>
        </div>
       </div>
      </div>
      </div>
      <div  className="justify-start flex mt-5 ">
        <img className="max-[1050px]:h-[80px]" src={left} alt="" />
      </div>
    </div>
  );
};

export default Contact;
