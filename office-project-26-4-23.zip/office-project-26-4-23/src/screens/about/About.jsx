import leftimg from "../../assets/1.png";
import rightimg from "../../assets/2.png";
import center1 from "../../assets/3.png";
import Navbar from "../../components/Navbar";

const About = () => {
  return (
   <>
      <Navbar />
      
      
       <div className="right-img flex  justify-end">
          <img className="mt-5 max-[1150px]:w-[80px] h-[100px]:max-[375px]:h-[80px]" src={leftimg} alt="" />
        </div>

        <div className="parent-div flex-wrap flex justify-evenly">
        <div className="child-1 ">
          <p className="text-3xl font-semibold max-[375px]:text-lg ml-4 max-[414px]: text-lg:ml-4 animate__animated animate__fadeInTopLeft">
            What we do to help <br /> our customers in <br /> digital era.
          </p>
          <div className="h-[525px] w-[380px] mt-28 bg-white rounded-lg drop-shadow-xl animate__animated animate__fadeInLeft">
            <div className="flex justify-center image1">
              <img className="mt-5 text-center" src={center1} alt="" />
            </div>
            <div className="image1 para text">
              <p className="font-semibold ml-16">Send</p>
              <p className="font-light ml-16 mt-7">
                Lorem ipsum dolor sit amet, <br /> consectetur adipiscing elit,
                sed do <br /> eiusmod tempor incididunt ut <br />
                labore et dolore magna aliqua.
              </p>
              <p className="ml-16 mt-16 font-normal text-blue-400">
                Learn More
              </p>
            </div>
          </div>
        </div>
        


        <div className="child-2">
        <div className="h-[525px] w-[380px]  bg-white rounded-lg drop-shadow-xl animate__animated animate__fadeInRight">
            <div className="flex justify-center image1">
              <img className="mt-5 text-center mx-[700px]:hidden" src={center1} alt="" />
            </div>
            <div className="image1 para text">
              <p className="font-semibold ml-16">Send</p>
              <p className="font-light ml-16 mt-7 animate__animated animate__fadeInTopLeft">
                Lorem ipsum dolor sit amet, <br /> consectetur adipiscing elit,
                sed do <br /> eiusmod tempor incididunt ut <br />
                labore et dolore magna aliqua.
              </p>
              <p className="ml-16 mt-16 font-normal text-blue-400">
                Learn More
              </p>
            </div>
          </div>
          

          <div className="h-[525px] w-[380px] bg-white rounded mt-16 lg drop-shadow-xl animate__animated animate__fadeInBottomRight">
            <div className="flex justify-center image1">
              <img className="mt-5 text-center" src={center1} alt="" />
            </div>
            <div className="image1 para text">
              <p className="font-semibold ml-16">Send</p>
              <p className="font-light ml-16 mt-7">
                Lorem ipsum dolor sit amet, <br /> consectetur adipiscing elit,
                sed do <br /> eiusmod tempor incididunt ut <br />
                labore et dolore magna aliqua.
              </p>
              <p className="ml-16 mt-16 font-normal text-blue-400">
                Learn More
              </p>
            </div>
          </div>
       </div>
       </div>
       <div className="right-img flex  justify-start">
          <img className="mt-5 max-[1150px]:w-[80px] h-[100px]:max-[375px]:h-[80px]" src={rightimg} alt="" />
        </div>

       
     
  
      
      </>
  );
};

export default About;
