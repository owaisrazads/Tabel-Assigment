import Navbar from "../../components/Navbar";
import Slider from "../../components/Slider";
import mobile from "..//../assets/Mockup.png";
import mbl1 from "..//../assets/mbl-1.avif";
import mbl2 from "..//../assets/mbl-2.avif";
import mbl3 from "..//../assets/mbl-3.avif";
import mbl4 from "..//../assets/mbl-4.avif";
import exploreImg from "..//../assets/explore-img.webp";

const Home = () => {
  return (
    <>
      <Navbar />
      <Slider />
      <div className="parent-div flex flex-wrap justify-evenly mt-[50px] mb-5">
        <div className="child-1 mt-[100px]">
          <div className="para">
            <p className="font-bold text-5xl mb-5 max-[1050px]:text-3xl max-[500px]:text-2xl max-[425px]:text-lg animate__animated animate__rotateInDownLeft">
              New E-commerce App <br />
              best for You
            </p>
            <p className="mb-[80px] max-[1050px]:mb-[60px] max-[500px]:text-sm max-[375px]:text-[5px]:mb-[30px]">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Amet{" "}
              <br /> sed vulputate vitae velit dictum cursus amet. Turpis donec
              ut <br /> velit quis. Cursus commodo, eget urna, sapien amet.
            </p>
          </div>
          <div className="button-div max-[828px]:mb-10 max-[500px]:mb-2 max-[px]:text-2xl">
            <button className="bg-[#4A99D3] px-4 py-2 rounded-md text-white hover:bg-red">
              Play Store
            </button>
            <button className="bg-[#4A99D3] px-4 py-2 rounded-md text-white ml-4">
              App Store
            </button>
          </div>
        </div>
        <div className="child-2 flex ">
          <img
            className="max-[1050px]:h-[480.78px] max-[500px]:h-[350.78px]"
            src={mobile}
            alt=""
          />
        </div>
      </div>

      {/* Recomended Products */}

      <div className="text-center font-bold text-4xl mt-5">
        <p>Recomended Products</p>
      </div>
      <div className="recomended-div flex justify-evenly flex-wrap">
        <div className="child-1 bg-blue-300  w-[40vh] h-[80vh] rounded-3xl max-[375px]:h-[70vh] max-[375px]: mt-10 ">
          <div className="flex justify-center">
            <img className="mt-8 max-[375px]:mt-4" src={mbl1} alt="" />
          </div>
          <div className="text-center">
            <p className="font-bold mt-4 max-[375px]:mt-2">Galaxy A54 5G</p>
            <p className="font-medium text-sm mt-5 max-[375px]:mt-2">
              Color : <span className=" text-sm font-normal">Light Green</span>
            </p>
            <button className="px-2 border-2 border-black rounded-3xl text-black text-sm mt-5">
              256 GB
            </button>
            <p className="font-medium text-lg mt-5 max-[375px]:mt-3">
              RS: 220,000
            </p>
            <button className="w-full p-2  mt-9 font-medium text-base  bg-white rounded-2xl text-black">
              Buy Now
            </button>
          </div>
        </div>

        <div className="child-2 bg-blue-300  w-[40vh] h-[80vh] rounded-3xl max-[375px]:h-[70vh] max-[375px]: mt-10">
          <div className="flex justify-center">
            <img className="mt-8  max-[375px]:mt-4" src={mbl2} alt="" />
          </div>
          <div className="text-center">
            <p className="font-bold mt-4 max-[375px]:mt-2">
              55 Crystal UHD 4K CU8000
            </p>
            <p className="font-medium text-sm mt-5 max-[375px]:mt-2">
              Color : <span className=" text-sm font-normal">Light Green</span>
            </p>
            <button className="px-2 border-2 border-black rounded-3xl text-black text-sm mt-5">
              256 GB
            </button>
            <p className="font-medium text-lg mt-5">RS: 220,000</p>
            <button className="w-full p-2  mt-9 font-medium text-base  bg-white rounded-2xl text-black">
              Buy Now
            </button>
          </div>
        </div>

        <div className="child-3 bg-blue-300  w-[40vh] h-[80vh] rounded-3xl max-[375px]:h-[70vh] max-[375px]: mt-10">
          <div className="flex justify-center">
            <img className="mt-8 max-[375px]:mt-4" src={mbl3} alt="" />
          </div>
          <div className="text-center">
            <p className="font-bold mt-4 max-[375px]:mt-2">Galaxy Tav A7Lite</p>
            <p className="font-medium text-sm mt-5">
              Color : <span className=" text-sm font-normal">Light Green</span>
            </p>
            <button className="px-2 border-2 border-black rounded-3xl text-black text-sm mt-5">
              256 GB
            </button>
            <p className="font-medium text-lg mt-5">RS: 220,000</p>
            <button className="w-full p-2  mt-9 font-medium text-base  bg-white rounded-2xl text-black">
              Buy Now
            </button>
          </div>
        </div>

        <div className="child-4 bg-blue-300  w-[40vh] h-[80vh] rounded-3xl max-[375px]:h-[70vh] max-[375px]: mt-10">
          <div className="flex justify-center">
            <img className="mt-8 max-[375px]:mt-4" src={mbl4} alt="" />
          </div>
          <div className="text-center">
            <p className="font-bold mt-4 max-[375px]:mt-2">Galaxy A34 5G</p>
            <p className="font-medium text-sm mt-5 max-[375px]:mt-2">
              Color : <span className=" text-sm font-normal">Light Green</span>
            </p>
            <button className="px-2 border-2 border-black rounded-3xl text-black text-sm mt-5">
              256 GB
            </button>
            <p className="font-medium text-lg mt-5">RS: 220,000</p>
            <button className="w-full p-2  mt-9 font-medium text-base  bg-white rounded-2xl text-black">
              Buy Now
            </button>
          </div>
        </div>
      </div>

      {/* Explore products */}

      <div className="explore-div">
        <p className="text-center font-bold text-4xl mt-10">
          Explore #DoWhatYouCant
        </p>
      <div className="flex justify-evenly mt-10">
      <div className="explore-img">
          <img
            className="max-[375px]:mt-4 rounded-3xl h-[512px]"
            src={exploreImg}
            alt=""
          />
        </div>
        <div className="explore-para ">
          <p className="font-bold text-2xl mt-5">
            4 Eco-Friendly Tech Tips to Shrink Your Carbon <br /> Footprint
          </p>
          <p className="font-bold text-2xl mt-5">How HDR Changes The Way You Game</p>
          <p className="font-bold text-2xl mt-5">Meet G·NUSMAS, the curious extraterrestrial</p>
        </div>
      </div>
      </div>
    </>
  );
};

export default Home;
