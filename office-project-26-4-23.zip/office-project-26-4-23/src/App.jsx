import Router from "./routerConfig/router";

const App = () => {
  return (
    <div>
     
      <Router />
    </div>
  );
};

export default App;
